#ifndef trLCD128x64_h
#define trLCD128x64_h

#include "Arduino.h"

#define GF_CLEAR_BUFFER	1
#define GF_LEAVE_BUFFER	0

#define GF_SOLID	1
#define GF_NO_FILL	0

class trLCD128x64
{

    public:
	trLCD128x64();

	void Init(void);
	void ClearDisplay();
	void UpdateDisplay(unsigned char ClearBuffer);

	void SetPixel(unsigned char X,unsigned char Y);
	void ClearPixel(unsigned char X,unsigned char Y);

	void SetColor(unsigned char c);
	void SetFill(unsigned char Solid);
	void HLine(unsigned char X,unsigned char Y,unsigned char Width);
	void VLine(unsigned char X,unsigned char Y,unsigned char Height);
	void Rect(unsigned char X,unsigned char Y,unsigned char Width,unsigned char Height);
	void Line(int x0,int y0,int x1,int y1);
	void Circle(unsigned int xc,unsigned int yc,unsigned int r);
	void SelectFont(unsigned char Id);
	void Putc(unsigned char X,unsigned char Y,unsigned char c);
	void Puts(unsigned char X,unsigned char Y,char s[]);

	void TerminalInit();
	void TerminalScroll();
	void TerminalSetCursor(unsigned char X, unsigned char Y);
	void TerminalPuts(char s[]);

    private:
	void CopyRect(unsigned char SrcX,unsigned char SrcY,unsigned char Width,unsigned char Height,unsigned char DstX,unsigned char DstY);
 	void trLCD128x64::CirclePixel(unsigned char xc,unsigned char yc,unsigned
char x,unsigned char y);

	    // Helper functions to communicate with LCD controllers.
	void FloatData(void);
	void DriveData(void);
	unsigned char ReadLCDCommand(unsigned char Which);
	void WriteLCDCommand(unsigned char Mask,unsigned char Cmd);
	unsigned char ReadLCDData(unsigned char Which);
	void WriteLCDData(unsigned char Which,unsigned char Data);
	unsigned char WaitUntilNotBusy(unsigned char Which);
	void SetXYAddr(unsigned char Mask,unsigned char X,unsigned char Y);

	unsigned char FrameBuffer[128*64/8];
	unsigned char mColor,mFill,mFontId;
	unsigned char mFontWidth;
	unsigned char mFontHeight;
};
#endif
